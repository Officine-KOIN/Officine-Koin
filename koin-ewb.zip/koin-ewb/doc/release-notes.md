(note: this is a temporary file, to be added-to by anybody, and deleted at
release time)

0.8.5 changes
=============

Workaround negative version numbers serialization bug.
